<?php
session_start();
error_reporting(0);
include "koneksi.php";
date_default_timezone_set("Asia/Makassar");

echo " ";

/* script menentukan hari */
$array_hr = array(1 => "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu");
$hr = $array_hr[date('N')];

/* script menentukan tanggal */
$tgl = date('j');

/* script menentukan bulan */
$array_bln = array(1 => "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
$bln = $array_bln[date('n')];
/* script menentukan tahun */
$thn = date('Y');
/* script perintah keluaran*/
$tanggal = $hr . ", " . $tgl . " " . $bln . " " . $thn;

?>











<style>
	h1,
	h2,
	p,
	a {
		font-family: sans-serif;
		font-weight: normal;
	}

	.jam-digital-malasngoding {
		overflow: hidden;

		width: 330px;
		margin: 20px auto;
		border: 5px solid #efefef;
	}

	.kotak {
		float: left;
		width: 100px;
		height: 100px;
		color: black;
	}

	.jam-digital-malasngoding p {
		color: black;
		font-size: 36px;
		text-align: center;
		margin-top: 30px;
	}
</style>



<div class="jam-digital-malasngoding">
	<div class="kotak">
		<p id="jam"></p>
	</div>
	<div class="kotak">
		<p id="menit"></p>
	</div>
	<div class="kotak">
		<p id="detik"></p>
	</div>
</div>



<script>
	window.setTimeout("waktu()", 1000);

	function waktu() {
		var waktu = new Date();
		setTimeout("waktu()", 1000);
		document.getElementById("jam").innerHTML = waktu.getHours();
		document.getElementById("menit").innerHTML = waktu.getMinutes();
		document.getElementById("detik").innerHTML = waktu.getSeconds();
	}
</script>

















<script src="jquery-1.11.3.js"></script>
<script>
	$(document).ready(function() {

		$("#ambilnomer").click(function() {

			// script untuk mendapatkan nmr antrian
			$.ajax({
				type: "POST",
				url: "ambilnomerantrian.php",
				data: "id=A",
				success: function(html) {
					$("#layernomer").html("<h1 >Nomor Antrian Anda : A" + String(html) + "</h1>")

					//update nmr antrian yg didapat ke template print
					var url = "templateprint.php?nmr=" + html;
					$("#templateprint").attr("src", url);
				}
			})

		})

		//script untuk meminta nmr yg ada di petugas saat ini
		window.setInterval(function() {
			$("#waktu").load("nomorkini.php");
		}, 1000);

	})
</script>

<script>
	$(document).ready(function() {

		$("#ambilnomer2").click(function() {
			// script untuk mendapatkan nmr antrian
			$.ajax({
				type: "POST",
				url: "ambilnomerantrian2.php",
				data: "id=B",
				success: function(html) {
					$("#layernomer").html("<h1 >Nomor Antrian Anda : B" + String(html) + "</h1>")

					//update nmr antrian yg didapat ke template print
					var url = "templateprint.php?nmr=" + html;
					$("#templateprint").attr("src", url);
				}
			})

		})

		//script untuk meminta nmr yg ada di petugas saat ini
		window.setInterval(function() {
			$("#waktu2").load("nomorkini2.php");
		}, 1000);

	})
</script>

<script>
	$(document).ready(function() {

		$("#ambilnomer3").click(function() {
			// script untuk mendapatkan nmr antrian
			$.ajax({
				type: "POST",
				url: "ambilnomerantrian3.php",
				data: "id=C",
				success: function(html) {
					$("#layernomer").html("<h1 >Nomor Antrian Anda : C" + String(html) + "</h1>")

					//update nmr antrian yg didapat ke template print
					var url = "templateprint.php?nmr=" + html;
					$("#templateprint").attr("src", url);
				}
			})

		})

		//script untuk meminta nmr yg ada di petugas saat ini
		window.setInterval(function() {
			$("#waktu3").load("nomorkini3.php");
		}, 1000);

	})
</script>

<script>
	$(document).ready(function() {

		$("#ambilnomer4").click(function() {
			// script untuk mendapatkan nmr antrian
			$.ajax({
				type: "POST",
				url: "ambilnomerantrian4.php",
				data: "id=D",
				success: function(html) {
					$("#layernomer").html("<h1 >Nomor Antrian Anda : D" + String(html) + "</h1>")

					//update nmr antrian yg didapat ke template print
					var url = "templateprint.php?nmr=" + html;
					$("#templateprint").attr("src", url);
				}
			})

		})

		//script untuk meminta nmr yg ada di petugas saat ini
		window.setInterval(function() {
			$("#waktu4").load("nomorkini4.php");
		}, 1000);

	})
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<style type="text/css">
	body {

		background-repeat: no-repeat;
		background-color: #000;
		background-size: auto;
	}

	#trik_atas {
		position: fixed;
		_position: absolute;
		height: 50px;
		bottom: 0px;
		left: 0;
		right: 0;
		clip: inherit;
		z-index: 2;
		_top: expression(document.documentElement.scrollTop+ document.documentElement.clientHeight-this.clientHeight);
		_left: expression(document.documentElement.scrollLeft+ document.documentElement.clientWidth - offsetWidth);
	}

	#trik_top {
		position: fixed;
		_position: absolute;
		top: 0px;
		left: 0;
		right: 0;
		clip: inherit;
		z-index: 2;
		_top: expression(document.documentElement.scrollTop+ document.documentElement.clientHeight-this.clientHeight);
		_left: expression(document.documentElement.scrollLeft+ document.documentElement.clientWidth - offsetWidth);
	}

	#float-left {
		position: fixed;
		_position: absolute;
		top: 0px;
		float: left;
		margin-left: -500px;
		z-index: 10;
		clip: inherit;
		_top: expression(document.documentElement.scrollTop+ document.documentElement.clientHeight-this.clientHeight);
		_left: expression(document.documentElement.scrollLeft+ document.documentElement.clientWidth - offsetWidth);
	}

	#float-right {
		position: fixed;
		_position: absolute;
		top: 0px;
		float: right;
		margin-left: 641px;
		z-index: 10;
		clip: inherit;
		_top: expression(document.documentElement.scrollTop+ document.documentElement.clientHeight-this.clientHeight);
		_left: expression(document.documentElement.scrollLeft+ document.documentElement.clientWidth - offsetWidth);
	}

	.atas {
		font-size: 24px;
	}

	.atas {
		color: #CCC;
	}

	.atase {
		font-size: 18px;
	}

	.aaas {
		font-size: 18px;
	}

	.adasd {
		font-size: 16px;
	}

	.atas .adasd {
		color: #CCC;
	}

	.cdd {
		color: #9C0;
		font-size: 24px;
	}

	.videoplace {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 16px;
		font-style: normal;
		color: #F60;

	}
</style>
<html xmlns="http://www.w3.org/1999/xhtml">



<head>
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">


	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title>Puskesmas UNISBANK</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="fonts/css/font-awesome.min.css" rel="stylesheet">
	<link href="css/animate.min.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
	<link href="css/icheck/flat/green.css" rel="stylesheet">
	<script src="js/jquery.min.js"></script>
</head>

<body style="background:url(images/bg.png);">



	<table style="margin-top:10px" width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td>
				<div id="trik_top"><? include "atas.php"; ?></div>
			</td>
		</tr>
		<td width="33%">
			<div>




				<div style="margin-top:-10px">

					<div id="" class="animate shake">
						<section class="login_content">
							<img src='images/logok.png' style='height:80px;'>
							<img src='images/puskesmas.png' style='height:80px;'>

							<h4> <b>
									<font color="black">KAMPUS UNISBANK</font>
								</b></h4>
							<h4> <b>
									<font color="black">DINAS KESEHATAN</font>
								</b></h4><br>

							<form>
								<H1><b>
										<font color="black">PUSKESMAS UNISBANK</font>
									</b></h1><br>
								<font color="black">
									<div id="waktu"></div>
									<font color="black">
										<div id="waktu2"></div>
										<font color="black">
											<div id="waktu3"></div>
											<font color="black">
												<div id="waktu4"></div>
												<h2>
													<font color="red" size="5"> <?php echo $tanggal; ?></font>
												</h2>


												<!-- iframe template untuk print yang dihidden -->
												<iframe id='templateprint' style='display:none' name='frame1'></iframe>

												<head>
													<!-- <input type=button value='Cetak Antrian' id='ambilprint' name='ambilprint'> -->






							</form>
							<!-- form -->
						</section>
						<!-- content -->
					</div>

				</div>
			</div>
		</td>


		<td bgcolor="black" align="right">
			<table valign="bottom" border="2" color="black" width="47%" cellspacing="" cellpadding="" style="padding-right:10px">


				<tr valign="bottom">
					<div style="margin-top:5px">
						<video width="914" controls preload="metadata">
							<source src="Video.mp4" type="video/mp4" />
						</video>
						<? include "showvideo.php"; ?>
					</div>
				</tr>
				<tr>
					<td>
						<div id="trik_atas"><? include "tampilow.php"; ?></div>
					</td>
				</tr>

			</table>
		</td>
	</table>



</body>

</html>

<?php
include "admin/suara.php";
?>