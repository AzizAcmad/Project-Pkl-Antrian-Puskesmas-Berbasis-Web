<meta http-equiv="refresh" content="3000"><?
include "../koneksi.php";



//tampil info_terkini scrolling
$low=mysql_query("select * from info_terkini order by id DESC");

?>

<table width="100%" border="0" cellpadding="0" cellspacing="0">
 <tr align="center" bgcolor="#F05205" valign="middle">
   <td  align="center" bgcolor="#003300" width="495" background="../img/fade5.gif"><font size=5 color=white>
   
   <img src='../images/indonesia_sehat.png' style='width:100px;'>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src='../images/pkm.png' style='height:40px;'><br></td>
   
 <td width="745" align="center" height="50" valign="middle" style="padding-left:20px; padding-right:20px; background-size:1000px">
<marquee direction="left" scrolldelay="90">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr align="center" valign="middle">
  <? while ($hasil=mysql_fetch_array($low)){ ?>
    <td align="center" valign="middle">
	
	<? echo "<b><font size=5 color=yellow>$hasil[2] </font></b><font size=5 color=black> >>> $hasil[3] <<< </font>&nbsp;<font size=5 color=white> Contact Person : $hasil[5] &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;</font>";?></td>
    <? } ?>
  </tr>
</table></marquee>
</td>
</tr>
</table>