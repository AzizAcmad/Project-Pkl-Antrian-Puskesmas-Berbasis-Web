<?php
include "mysql_mysqli.inc.php";
	$host="localhost";
	$user="root";
	$pswd="";
	$db="antrian";
	mysql_Connect("$host","$user","$pswd");
	mysql_select_db("$db");

	?>
	
