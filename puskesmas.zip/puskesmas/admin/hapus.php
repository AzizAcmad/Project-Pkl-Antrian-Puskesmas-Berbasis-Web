<?php
session_start();
include "../koneksi.php";
mysql_query("delete from alamat");
mysql_query("delete from nokini");
mysql_query("delete from nokini_b");
mysql_query("delete from nokini_c");
mysql_query("delete from nokini_d");
echo "<meta http-equiv=refresh content='0;url=index.php'>";
?>