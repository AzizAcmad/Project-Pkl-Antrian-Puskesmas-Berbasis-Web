<?php session_start();
error_reporting(0);
include "mysql_mysqli.inc.php";
include "koneksi.php";
		date_default_timezone_set("Asia/Semarang");

		echo " ";

		/* script menentukan hari */  
		$array_hr= array(1=>"Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu");
		$hr = $array_hr[date('N')];

		/* script menentukan tanggal */    
		$tgl= date('j');

		/* script menentukan bulan */ 
		$array_bln = array(1=>"Januari","Februari","Maret", "April", "Mei","Juni","Juli","Agustus","September","Oktober", "November","Desember");
		$bln = $array_bln[date('n')];
		/* script menentukan tahun */ 
		$thn = date('Y');
		/* script perintah keluaran*/ 
		$tanggal=$hr . ", " . $tgl . " " . $bln . " " . $thn;
		
		$antrian=mysql_query("SELECT * FROM alamat WHERE loket='A'");
		$sudah=mysql_query("SELECT * FROM no_kini WHERE loket='A'");
		$sisa=mysql_num_rows($antrian)-$num=mysql_num_rows($sudah);
?>
<style>
  header{border-style:double; margin-top:20px; padding:20px; text-align:center; font-family:Arial,Helvetica,sans-serif; font-size:25px;}
  .tampilan{border-style:double; margin-top:20px; padding:10px; text-align:center; font-family:Arial,Helvetica,sans-serif; font-size:30px;}
  .tombol{border-style:double; margin-top:20px; padding:10px; text-align:center; font-family:Arial,Helvetica,sans-serif; font-size:30px;}
  h1{text-align:center; margin-top:30px; font-family:Arial,Helvetica,sans-serif;}
</style>

<script src="jquery-1.11.3.js"></script>
<script>
	$(document).ready(function(){
		$("#Panggil4").click(function(){
			$.ajax({
				type:"POST",
				url:"panggilnomer4.php",
				data:"id=D",
				success:function(html){
					$("#layerl4").html("K I A : "+html)
				}})
			
		})
		
		$("#Panggil3").click(function(){
			$.ajax({
				type:"POST",
				url:"panggilnomer3.php",
				data:"id=C",
				success:function(html){
					$("#layerl3").html("Poli Gigi : "+html)
				}})
			
		})
		
		$("#Panggil2").click(function(){
			$.ajax({
				type:"POST",
				url:"panggilnomer2.php",
				data:"id=B",
				success:function(html){
					$("#layerl2").html("Poli Dewasa : "+html)
				}})
			
		})

		$("#Panggil1").click(function(){
			$.ajax({
				type:"POST",
				url:"panggilnomer.php",
				data:"id=A",
				success:function(html){
					$("#layerl1").html("Poli Umum : "+html)
				}})
			
		})
		
		

})
	</script>
<style type="text/css">
body
{

background-repeat: no-repeat;
background-color: #000;
background-size:auto;
} 
#trik_atas {position:fixed;_position:absolute;bottom:0px; left:0;right:0;clip:inherit;z-index: 2;
_top:expression(document.documentElement.scrollTop+
document.documentElement.clientHeight-this.clientHeight);
_left:expression(document.documentElement.scrollLeft+
document.documentElement.clientWidth - offsetWidth);}

#trik_top {position:fixed;_position:absolute;top:0px;left:0;right:0;clip:inherit;z-index: 2;
_top:expression(document.documentElement.scrollTop+
document.documentElement.clientHeight-this.clientHeight);
_left:expression(document.documentElement.scrollLeft+
document.documentElement.clientWidth - offsetWidth);}

#float-left{position:fixed;_position:absolute;top:0px;float:left; margin-left:-500px;z-index:10;
clip:inherit;_top:expression(document.documentElement.scrollTop+
document.documentElement.clientHeight-this.clientHeight);
_left:expression(document.documentElement.scrollLeft+
document.documentElement.clientWidth - offsetWidth);}
#float-right{
position:fixed;_position:absolute;top:0px;float:right; margin-left:641px;z-index:10;
clip:inherit;_top:expression(document.documentElement.scrollTop+
document.documentElement.clientHeight-this.clientHeight);
_left:expression(document.documentElement.scrollLeft+
document.documentElement.clientWidth - offsetWidth);}
.atas {
	font-size: 24px;
}
.atas {
	color: #CCC;
}
.atase {
	font-size: 18px;
}
.aaas {
	font-size: 18px;
}
.adasd {
	font-size: 16px;
}
.atas .adasd {
	color: #CCC;
}
.cdd {
	color: #9C0;
	font-size: 24px;
}
.videoplace {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 16px;
	font-style: normal;
	color: #F60;
	
}
</style>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Puskesmas UNISBANK</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../fonts/css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/animate.min.css" rel="stylesheet">
    <link href="../css/custom.css" rel="stylesheet">
    <link href="../css/icheck/flat/green.css" rel="stylesheet">
    <script src="../js/jquery.min.js"></script>
</head>

<body style="background:url(../images/bg.png); height:flexible">
<div id="trik_top">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
 <tr align="center" bgcolor="black" valign="middle">
   <td align="center" bgcolor="#003300" width="555" ><b><font size=5 color=white>Puskesmas</font><font size=5 color=white> UNISBANK</font></b><br>
   <td bgcolor="#003300" width="2" background="img/fade.gif"><font size=5 color=yellow></font><br>
  
 <td width="745" align="center" height="50" valign="middle" style="padding-left:20px; padding-right:20px; background-size:1000px">
<marquee direction="left" scrolldelay="50"><font valign="center" color="white" face="Calibri, Geneva, sans-serif" size="5"><b>Selamat Bekerja</b></font></marquee>
</td>
<td <font size=5 width="125" align="middle" bgcolor="#006633"><b><? include "../jam.html";?></b></td></tr>
</table> </div>   
    
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">

<td  width="40%">    
	<div class="">

        <div style="margin-top:90px">
		
            <div id="" class="animate shake">
                <section class="login_content">
				<img src='../images/logok.png' style='height:100px;'>
				<img src='../images/puskesmas.png' style='height:100px;'>
				
                    <h4> <font size="5" color="black">KAMPUS UNISBANK</font></h4>
					<h4> <font size="5" color="black">DINAS KESEHATAN</h4><br>
                    <form >
						<H1><font size="5" color="black">PUSKESMAS UNISBANK</font></h1>
                <h2><font size="5"> <?php echo $tanggal; ?></h2>
		</div>
</td>		
<td  class="login_content" align="center">		
<div style="margin-top:90px"><font color="green" size="5px">	

<div id='layersuara' style='display:none'></div>
<div id='layerl1'>Poli Umum </div>
<div id='layerl2'>Poli Dewasa </div>
<div id='layerl3'>Poli Gigi </div>
<div id='layerl4'>K I A </div></font>

</div><br>

<div class="">	
<input style='font-size:24px; width:130px; background:orange; color:black' type='button' class="btn btn-danger" value='A' id='Panggil1' name='Panggil1' >
<input style='font-size:24px; width:130px; background:red; color:black' type='button' class="btn btn-primary" value='B' id='Panggil2' name='Panggil2'>
<input style='font-size:24px; width:130px; background:yellow; color:black' type='button' class="btn btn-success" value='C' id='Panggil3' name='Panggil3'>
<input style='font-size:24px; width:130px; background:blue; color:black' type='button' class="btn btn-warning" value='D' id='Panggil4' name='Panggil4'>
</div>
<br><br>
<div class="">	


<a href='hapus.php' style='text-decoration:none'>
<input type='button' value='Reset Nomor Antrian' id='Reset' name='Reset'></a>


</div>	
</td>		
                        
<tr>
         <td ><div id="trik_atas"><? include "tampilow2.php";?></div></td>
</tr>                        
                    </form>
                    <!-- form -->
                </section>
                <!-- content -->
            
</body>
