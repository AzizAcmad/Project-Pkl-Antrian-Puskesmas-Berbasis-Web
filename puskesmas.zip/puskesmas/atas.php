<meta http-equiv="refresh" content="3000">



<table width="100%" border="2" cellpadding="0" cellspacing="0">
 <tr align="center" bgcolor="black" valign="middle">
   <td width="33%" valign="middle"  align="center" bgcolor="#003300"  >
   <b><font size=5 color=white>Puskesmas </font><font size=5 color=red> UNISBANK</font></b>
   </td>
   
 <td width="860"  align="center" height="50" valign="middle" style="padding-left:20px; padding-right:20px; background-size:1000px">
<marquee direction="left" scrolldelay="50"><font valign="center" color="white" face="Calibri, Geneva, sans-serif" size="5">&nbsp;&nbsp;<b>Selamat Datang di Puskesmas UNISBANK Kota SEMARANG</b></font></marquee></marquee>
</td>
<td width="10%" align="middle" bgcolor="#006633"><font size=5 ><b><? include "jam.html";?></b></font></td>
</tr>
</table>
