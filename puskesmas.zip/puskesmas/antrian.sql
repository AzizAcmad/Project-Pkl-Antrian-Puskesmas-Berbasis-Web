-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Jun 2021 pada 17.27
-- Versi server: 10.4.18-MariaDB
-- Versi PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `antrian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alamat`
--

CREATE TABLE `alamat` (
  `id_alamat` int(11) NOT NULL,
  `ip_alamat` varchar(20) NOT NULL,
  `jam_ambilnomer` datetime NOT NULL,
  `nomor` int(11) NOT NULL,
  `loket` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `alamat`
--

INSERT INTO `alamat` (`id_alamat`, `ip_alamat`, `jam_ambilnomer`, `nomor`, `loket`) VALUES
(82, '::1', '2021-06-26 23:57:25', 1, 'A'),
(83, '::1', '2021-06-26 23:58:25', 1, 'B'),
(84, '::1', '2021-06-26 23:59:25', 1, 'C'),
(85, '::1', '2021-06-26 23:59:25', 1, 'D'),
(86, '::1', '2021-06-26 23:00:26', 2, 'A'),
(87, '::1', '2021-06-26 23:00:26', 2, 'B'),
(88, '::1', '2021-06-26 23:00:26', 2, 'C'),
(89, '::1', '2021-06-26 23:00:26', 2, 'D'),
(90, '::1', '2021-06-26 23:01:26', 3, 'A'),
(91, '::1', '2021-06-26 23:01:26', 3, 'B'),
(92, '::1', '2021-06-26 23:02:26', 3, 'C'),
(93, '::1', '2021-06-26 23:02:26', 3, 'D'),
(94, '::1', '2021-06-26 23:02:26', 4, 'A'),
(95, '::1', '2021-06-26 23:03:26', 4, 'B'),
(96, '::1', '2021-06-26 23:03:26', 4, 'C'),
(97, '::1', '2021-06-26 23:03:26', 4, 'D'),
(98, '::1', '2021-06-26 23:04:26', 5, 'A'),
(99, '::1', '2021-06-26 23:04:26', 5, 'B'),
(100, '::1', '2021-06-26 23:04:26', 5, 'C'),
(101, '::1', '2021-06-26 23:05:26', 5, 'D'),
(102, '::1', '2021-06-26 23:05:26', 6, 'A'),
(103, '::1', '2021-06-26 23:05:26', 6, 'B'),
(104, '::1', '2021-06-26 23:06:26', 6, 'C'),
(105, '::1', '2021-06-26 23:06:26', 6, 'D');

-- --------------------------------------------------------

--
-- Struktur dari tabel `info_terkini`
--

CREATE TABLE `info_terkini` (
  `id` int(11) NOT NULL,
  `kategori` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `bidang` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `informasi` varchar(1000) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `syarat` text COLLATE latin1_general_ci NOT NULL,
  `kontak` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `info_terkini`
--

INSERT INTO `info_terkini` (`id`, `kategori`, `bidang`, `informasi`, `syarat`, `kontak`) VALUES
(10, '', 'Kepompok ', 'Angga,Aripe,Boby,Anjis', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nokini`
--

CREATE TABLE `nokini` (
  `id_nokini` int(11) NOT NULL,
  `no_kini` int(11) NOT NULL,
  `loket` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nokini`
--

INSERT INTO `nokini` (`id_nokini`, `no_kini`, `loket`) VALUES
(20, 1, 'A');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nokini_b`
--

CREATE TABLE `nokini_b` (
  `id_nokini` int(11) NOT NULL,
  `no_kini` int(11) NOT NULL,
  `loket` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nokini_b`
--

INSERT INTO `nokini_b` (`id_nokini`, `no_kini`, `loket`) VALUES
(9, 1, 'B'),
(10, 2, 'B'),
(11, 3, 'B');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nokini_c`
--

CREATE TABLE `nokini_c` (
  `id_nokini` int(11) NOT NULL,
  `no_kini` int(11) NOT NULL,
  `loket` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nokini_c`
--

INSERT INTO `nokini_c` (`id_nokini`, `no_kini`, `loket`) VALUES
(7, 1, 'C'),
(8, 2, 'C');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nokini_d`
--

CREATE TABLE `nokini_d` (
  `id_nokini` int(11) NOT NULL,
  `no_kini` int(11) NOT NULL,
  `loket` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nokini_d`
--

INSERT INTO `nokini_d` (`id_nokini`, `no_kini`, `loket`) VALUES
(3, 1, 'D');

-- --------------------------------------------------------

--
-- Struktur dari tabel `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `video` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `durasi` bigint(255) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alamat`
--
ALTER TABLE `alamat`
  ADD PRIMARY KEY (`id_alamat`);

--
-- Indeks untuk tabel `info_terkini`
--
ALTER TABLE `info_terkini`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `nokini`
--
ALTER TABLE `nokini`
  ADD PRIMARY KEY (`id_nokini`);

--
-- Indeks untuk tabel `nokini_b`
--
ALTER TABLE `nokini_b`
  ADD PRIMARY KEY (`id_nokini`);

--
-- Indeks untuk tabel `nokini_c`
--
ALTER TABLE `nokini_c`
  ADD PRIMARY KEY (`id_nokini`);

--
-- Indeks untuk tabel `nokini_d`
--
ALTER TABLE `nokini_d`
  ADD PRIMARY KEY (`id_nokini`);

--
-- Indeks untuk tabel `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `alamat`
--
ALTER TABLE `alamat`
  MODIFY `id_alamat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT untuk tabel `info_terkini`
--
ALTER TABLE `info_terkini`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `nokini`
--
ALTER TABLE `nokini`
  MODIFY `id_nokini` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `nokini_b`
--
ALTER TABLE `nokini_b`
  MODIFY `id_nokini` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `nokini_c`
--
ALTER TABLE `nokini_c`
  MODIFY `id_nokini` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `nokini_d`
--
ALTER TABLE `nokini_d`
  MODIFY `id_nokini` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `video`
--
ALTER TABLE `video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
