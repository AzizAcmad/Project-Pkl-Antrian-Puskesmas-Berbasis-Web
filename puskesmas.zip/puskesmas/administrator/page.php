<?php
//halaman awal
 if(isset($_GET['masuk'])){ 
include'sign-in.php';
}
 if(isset($_GET['keluar'])){ 
include'sign-out.php';
} 
if(isset($_GET['process-masuk'])){ 
include'process-sign-in.php';
}
if(isset($_GET['lupa-sandi'])){ 
include'reset.php';
}

//halaman error session
 if(isset($_GET['acces-admin'])){ 
include'system/error/acces-admin.php';
}
 if(isset($_GET['acces-kantor'])){ 
include'system/error/acces-kantor.php';
}
 if(isset($_GET['acces-skpd'])){ 
include'system/error/acces-skpd.php';
}
if(isset($_GET['error-404'])){ 
include'system/error/404.php';
}

//halaman admin
 if(isset($_GET['home'])){ 
include'home.php';
}
 if(isset($_GET['input_info'])){ 
include'input_info.php';
} 


//halaman kantor
 if(isset($_GET['g-home'])){ 
include'system/kantor/home.php';
}
 if(isset($_GET['g-data-absensi'])){ 
include'system/kantor/data-absensi.php';
}
if(isset($_GET['rekap-absensi'])){ 
include'system/kantor/rekap-absensi.php';
}

if(isset($_GET['cetak-rekap'])){ 
include'system/kantor/cetak_absensi_rekap.php';
}

if(isset($_GET['g-data-unit_kerja'])){ 
include'system/kantor/data-unit_kerja.php';
}
if(isset($_GET['g-data-pegawai'])){ 
include'system/kantor/data-pegawai.php';
}
if(isset($_GET['g-rekap-tahunan'])){ 
include'system/kantor/rekap-tahunan.php';
}
if(isset($_GET['g-edit-profil'])){ 
include'system/kantor/edit-profil.php';
}
 if(isset($_GET['g-process-edit-profil'])){ 
include'system/kantor/process-edit-profil.php';
}  
if(isset($_GET['g-detail-unit_kerja'])){ 
include'system/kantor/view-unit_kerja.php';
}  
if(isset($_GET['g-detail-pegawai'])){ 
include'system/kantor/view-pegawai.php';
}  
if(isset($_GET['g-detail-profil'])){ 
include'system/kantor/view-profil.php';
}
if(isset($_GET['g-about'])){ 
include'system/kantor/about.php';
}
if(isset($_GET['g-bantuan'])){ 
include'system/kantor/help.php';
}

//halaman skpd
 if(isset($_GET['s-home'])){ 
include'system/skpd/home.php';
}
 if(isset($_GET['data-absensi'])){ 
include'system/skpd/data-absensi.php';
}
if(isset($_GET['s-data-unit_kerja'])){ 
include'system/skpd/data-unit_kerja.php';
}
if(isset($_GET['s-data-pegawai'])){ 
include'system/skpd/data-pegawai.php';
}
if(isset($_GET['s-edit-profil'])){ 
include'system/skpd/edit-profil.php';
}
if(isset($_GET['absen-pegawai'])){ 
include'system/skpd/insert-absensi.php';
}
 if(isset($_GET['s-process-edit-profil'])){ 
include'system/skpd/process-edit-profil.php';
}  
if(isset($_GET['process-insert-absensi'])){ 
include'system/skpd/process-insert-absensi.php';
} 
if(isset($_GET['s-detail-unit_kerja'])){ 
include'system/skpd/view-unit_kerja.php';
}  
if(isset($_GET['s-detail-pegawai'])){ 
include'system/skpd/view-pegawai.php';
}  
if(isset($_GET['s-detail-profil'])){ 
include'system/skpd/view-profil.php';
}
if(isset($_GET['s-about'])){ 
include'system/skpd/about.php';
}
if(isset($_GET['s-bantuan'])){ 
include'system/skpd/help.php';
}
?>