<?

session_start();

include "../koneksi.php";
include "fungsi_indotgl.php";

$lihat=mysql_query("select * from tbl_kunjungan");
//$low=mysql_fetch_array($lihat);
$i=0;
?>
<head>


	
</head>
<h2 align="left" style="font-family:Calibri">Laporan Periode</h2>
<form action="" method="post" id="form-rekap" name="form-rekap">
						
									<input id="daterange3" type="text" name="tgl1" value="<?php echo $tanggal=date("d-m-Y"); ?>" >
									s/d
									<input id="daterange4" type="text" name="tgl2" value="<?php echo $tanggal=date("d-m-Y"); ?>" >
									
						
						
						
						
									<button id="form-rekap" name="form-rekap" type="submit"class="btn btn-default font-icon font-icon-server" data-toggle="tooltip" data-placement="top" title="Rekap"> &nbsp;Tampilkan Laporan</button>
</form>
<div align="left">Periode Tanggal : <b><?php echo $tgl1=$_POST['tgl1']; ?></b> s/d <b><?php echo $tgl2=$_POST['tgl2']; ?></b></div> 
											
<br>

					
<table style="font-family:Corbel" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%" align="center" bgcolor="#FF6600">No</td>
	
	
	<td width="15%" align="left" bgcolor="#FF6600">Loket - Layanan</td>
	<td width="15%" align="center" bgcolor="#FF6600">Jumlah</td>
	<td width="15%" align="center" bgcolor="#FF6600">Total Kunjungan</td>
 
  </tr>
  <?php

							$low=mysql_fetch_array($lihat);
							$tgl=tgl_indo($low[2]);
							$bln = date('m', strtotime($low[2]));
							$tanggal = date('d', strtotime($low[2]));
							$aktif=mysql_query("SELECT * FROM tbl_kunjungan WHERE tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif1=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='A' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif2=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='B' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif3=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='C' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif4=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='D' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$num1=mysql_num_rows($aktif1);
							$num2=mysql_num_rows($aktif2);
							$num3=mysql_num_rows($aktif3);
							$num4=mysql_num_rows($aktif4);
							$num=mysql_num_rows($aktif);

$i++;

  ?>
 
  <tr>
    <td align="center" style=" border-bottom-color: #3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$i;?></td>
	
	
	<td align="left" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted">A - Poli Umum<br>B - Poli Dewasa<br>C - Poli Gigi<br>D - KIA</td>
	<td align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted">
									
	<?=$num1;?><br><?=$num2;?><br><?=$num3;?><br><?=$num4;?> </td>
	<td align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$num;?> </td>
  </tr>

  
</table>
<div class="btn-group" role="group">
								
								<a target="blank" class="ngedit" href="../page.php?cetak-bulanan&tanggal=<?php echo $tgl1=$_POST['tgl1']; ?>&tgl=<?php echo $tgl2=$_POST['tgl2']; ?>" class="btn btn-default " data-toggle="tooltip" data-placement="top" title="Cetak"> Cetak Laporan</a>
								
							</div>
