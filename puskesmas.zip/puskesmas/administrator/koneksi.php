<?
include "mysql_mysqli.inc.php";
$koneksi=mysql_connect("localhost","root","root");
mysql_select_db("antrian(1)");


?>
