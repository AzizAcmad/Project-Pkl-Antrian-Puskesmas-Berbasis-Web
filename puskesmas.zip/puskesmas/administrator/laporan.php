<?
session_start();

include "../koneksi.php";
include "fungsi_indotgl.php";

?>

<h2 style="font-family:Calibri">Laporan Harian</h2>
<form action="" method="post" id="form-rekap" name="form-rekap">
						
									<input id="daterange3" type="text" name="tgl1" value="<?php echo $tanggal=date("d-m-Y"); ?>" >
									<button id="form-rekap" name="form-rekap" type="submit"class="btn btn-default font-icon font-icon-server" data-toggle="tooltip" data-placement="top" title="Rekap"> &nbsp;Tampilkan Laporan</button>
</form>
<div class="hidden" align="left"><?php $tgl1=$_POST['tgl1']; ?></div> 

<table style="font-family:Calibri" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%" align="center" bgcolor="#FF6600">No</td>
	<td width="15%" align="center" bgcolor="#FF6600">Tanggal</td>
	<td width="15%" align="center" bgcolor="#FF6600">Jam</td>
	<td width="15%" align="center" bgcolor="#FF6600">Id Pasien</td>
	<td width="35%" align="center" bgcolor="#FF6600">Nama Pasien</td>
    <td width="15%" align="center" bgcolor="#FF6600">No. Antrian</td>
    
     
  </tr>
  <? 
  $lihat=mysql_query("select * from tbl_kunjungan WHERE tanggal='$tgl1' order by id DESC");
	//$low=mysql_fetch_array($lihat);
	$i=0;
  while($low=mysql_fetch_array($lihat)){
$i++;
$tgl=$low[2]; 
  ?>
  <tr>
    <td align="center" style=" border-bottom-color: #3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$i;?></td>
	<td align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$tgl;?> </td>
	<td align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$low[3];?> </td>
	<td align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$low[1];?> </td>
    <td style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"> </td>
	<td align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$low[5];?><?=$low[4];?> </td>
    
	

    
    
    
  </tr>
  <? } ?>
</table>

<div class="btn-group" role="group">
								
								<a target="blank" class="ngedit" href="../page.php?cetak-harian&tanggal=<?php echo $tgl1;?>" class="btn btn-default " data-toggle="tooltip" data-placement="top" title="Cetak"> Cetak Laporan</a>
								
							</div>

