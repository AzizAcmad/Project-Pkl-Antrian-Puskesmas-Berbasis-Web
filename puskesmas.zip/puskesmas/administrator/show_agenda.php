<?
session_start();

include "../koneksi.php";
$lihat=mysql_query("select * from agenda order by id DESC");
//$low=mysql_fetch_array($lihat);
$i=0;
?>

<form action="index.php?menu=show_agenda.php&aksi=hapus" method="post" enctype="multipart/form-data">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%" align="center" bgcolor="#FF6600">No</td>
    <td width="35%" align="center" bgcolor="#FF6600">Kegiatan</td>
    <td width="29%" align="center" bgcolor="#FF6600">Tempat</td>
	<td width="29%" align="center" bgcolor="#FF6600">Waktu</td>
     <td colspan="2" align="center" bgcolor="#FF6600">Aksi</td>
  </tr>
  <? 
  while($low=mysql_fetch_array($lihat)){
$i++;
  ?>
  <tr>
    <td style=" border-bottom-color: #3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$i;?></td>
    <td style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$low[2];?></td>
    <td style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$low[3];?></td>
	<td style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><?=$low[5];?></td>
    <td width="17%" align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><a href="index.php?menu=edit_agenda.php&data=<?=$low[0];?>" class="ngedit">Edit</a></td>
    <td width="15%" align="center" style=" border-bottom-color:#3C0; border-top-color:#FFF;border-left-color:#FFF;  border-right-color:#FFF; border-style: dotted"><a href="index.php?menu=show_agenda.php&data=<?=$low[0];?>&aksi=hapus" class="ngedit">Hapus</a></td>
  </tr>
  <? } ?>
</table>
<?
if($_GET['aksi']=="hapus"){
	?>
    <p>
 <div style="border-color:#F00; background-color:#CF9; border-style: dotted; padding-top:10px; padding-left:10px; padding-bottom:10px" > 
    <?
$lihat=mysql_query("select * from agenda where id=$_GET[data]");
$hps=mysql_fetch_array($lihat);
	
echo "Yakin akan menghapus data bidang <b>$hps[2]</b> agenda <b>$hps[3]</b> ?";	
echo "<center><p> <a href=index.php?menu=show_agenda.php&uhui=ya&id=$_GET[data] class=tabel>[YA]</a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp; <a href=index.php?menu=show_agenda.php class=tabel>[TIDAK]</a></center>";

	
}
if($_GET['uhui']=="ya"){ $sql=mysql_query("delete from agenda where id=$_GET[id]");
if($sql) 
 echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?menu=show_agenda.php\">");
//header("location:index.php?menu=show_agenda.php");
}


?></div>