<?
include "../koneksi.php";

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

?>
<title>Administrator PUSKESMAS PUTRI AYU</title>
<style type="text/css">
.tablesatu {
	padding-left: 30px;
	padding-right: 20px;
	padding-top: 5px;
	padding-bottom: 5px;
	font-family:Corbel;
}
a.tabel:link{
		color:#F60;
		text-decoration:none;

}
a.tabel:hover{
		color: #FC0;
				text-decoration:underline;

}
a.tabel:visited{
		color:#F60;
				text-decoration:none;

}
a.tabel:active{
		color:#F60;
				text-decoration:none;

}
a.ngedit:link{
		color:#F60;
		text-decoration:none;
		font-family:Corbel;
}
a.ngedit:hover{
		color: #666;
				text-decoration:underline;

}
a.ngedit:visited{
		color:#F60;
				text-decoration:none;

}
a.ngedit:active{
		color:#F60;
				text-decoration:none;
				font-family:Corbel;

}


</style>


<table width="100%" cellspacing="0" cellpadding="0">
  <tr>
    
    <td align="center" valign="top"><img src="../images/puskesmas.png" width="30%"  /><br><h4>PUSKESMAS PUTRI AYU</h4></td>
    <td width="10%">&nbsp;</td>
  </tr>
  
  
  
  
	  
  <tr>
  
    <td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center"><img src="../img/admin.jpg" width="" height="" /></td>
      </tr>
      
	  
	  
      <tr>
        <td class="tablesatu"><img src="../img/left.JPG" width="10" height="10" style="alignment-adjust: middle; " /><a href="home.php?menu=input_info.php" class="tabel"> Input Info Terkini</a></td>
      </tr>
      <tr>
        <td class="tablesatu"><img src="../img/left.JPG" width="10" height="10" style="alignment-adjust: middle; " /><a href="home.php?menu=show_info.php" class="tabel"> Edit Info Terkini</a></td>
      </tr>
      
      <tr>
        <td class="tablesatu"><img src="../img/left.JPG" width="10" height="10" style="alignment-adjust: middle; " />  <a href="home.php?menu=inputvideo.php" class="tabel"> Input Video </a></td>
      </tr>
      <tr>
        <td class="tablesatu"><img src="../img/left.JPG" width="10" height="10" style="alignment-adjust: middle; " /> <a href="home.php?menu=showvideo.php" class="tabel"> Edit Video </a></td>
      </tr>
     
      
      <tr>
        <td class="tablesatu"><img src="../img/left.JPG" width="10" height="10" style="alignment-adjust: middle; " /> <a href="home.php?menu=laporan.php" class="tabel"> Laporan Kunjungan Harian</a></td>
      </tr>
	   <tr>
        <td class="tablesatu"><img src="../img/left.JPG" width="10" height="10" style="alignment-adjust: middle; " /> <a href="home.php?menu=laporan_bulanan.php" class="tabel"> Laporan Kunjungan Bulanan</a></td>
      </tr>
	  <tr>
        <td class="tablesatu"><img src="../img/left.JPG" width="10" height="10" style="alignment-adjust: middle; " /> <a href="home.php?menu=sign-out.php" class="tabel"> Keluar</a></td>
      </tr>
      <tr>
        <td align="center"><img src="../img/adminbwh.jpg" width="" height="" /></td>
      </tr>
    </table></td>
    <td width="65%" valign="top" style="padding-top:0px; padding-bottom:30px; padding-left:30px; padding-right:0px"> 
	
	<?
	
	if($_GET['menu']=="input_info.php") include "input_info.php";
	if($_GET['menu']=="show_info.php") include "show_info.php";
	if($_GET['menu']=="edit_info.php")  include "edit_info.php";
	
	if($_GET['menu']=="inputvideo.php") include "inputvideo.php";
	if($_GET['menu']=="showvideo.php") include "showvideo.php";
	if($_GET['menu']=="laporan.php") include "laporan.php";
	if($_GET['menu']=="laporan_bulanan.php") include "laporan_bulanan.php";
	if($_GET['menu']=="sign-out.php") include "sign-out.php";
	
	if($_GET['menu']=="rss.php") include "rss.php";
	?>
	</td>
    <td><a href="../index.php" target="_blank" class="ngedit">Preview</a> [Klik], Press F11 to Full Screen</td>
  </tr>
  
</table>

