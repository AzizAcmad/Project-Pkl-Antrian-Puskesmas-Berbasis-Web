

<?php 
error_reporting(0); 

include('koneksi.php');
include('css.php');


$tgl1=$_GET['tanggal'];
$tgl2=$_GET['tgl'];

?>
<html>
<head>
<title>Daftar Kunjungan Bulanan</title>
<link href="css/style_cetak.css" rel="stylesheet" type="text/css">
</head>
<body onload="window.print()">



<table style="font-family:Calibri" width="100%" border="0"  class="table-list">

<?php 
							$query=mysql_query("select * from tbl_kunjungan WHERE tanggal BETWEEN '$tgl1' AND '$tgl2' order by id DESC");
							$row=mysql_fetch_array($query);
							
							?>
							<h3 align="center" style="font-family:Calibri" >DAFTAR KUNJUNGAN PASIEN<br> PUSKESMAS PUTRI AYU</h3>
<tr>
    <center><td width="10"><h7>Periode Tanggal</h7></center></td>
    <td width="5"><strong>:</strong></td>
    <td width="490"><b><?php echo $tgl1; ?></b> s/d <b><?php echo $tgl2; ?></b></td>
  </tr>
</table>

<table style="font-family:Calibri" width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%" align="center" bgcolor="grey">No</td>
	
	
	<td width="15%" align="left" style="padding-left:10px" bgcolor="grey">Loket - Layanan</td>
	<td width="15%" align="center" bgcolor="grey">Jumlah Kunjungan</td>
	<td width="15%" align="center" bgcolor="grey">Total Kunjungan</td>
 
  </tr>
  <?php

							$low=mysql_fetch_array($lihat);
							
							$aktif=mysql_query("SELECT * FROM tbl_kunjungan WHERE tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif1=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='A' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif2=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='B' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif3=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='C' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$aktif4=mysql_query("SELECT * FROM tbl_kunjungan WHERE loket='D' AND tanggal BETWEEN '$tgl1' AND '$tgl2'");
							$num1=mysql_num_rows($aktif1);
							$num2=mysql_num_rows($aktif2);
							$num3=mysql_num_rows($aktif3);
							$num4=mysql_num_rows($aktif4);
							$num=mysql_num_rows($aktif);

$i++;

  ?>
 
  <tr>
    <td align="center" ><?=$i;?></td>
	
	
	<td align="left" style="padding-left:10px">A - Poli Umum<br>B - Poli Dewasa<br>C - Poli Gigi<br>D - KIA</td>
	<td align="center" >
									
	<?=$num1;?><br><?=$num2;?><br><?=$num3;?><br><?=$num4;?> </td>
	<td align="center" ><?=$num;?> </td>
  </tr>

  
</table>

</body>
</html>