

<?php 
error_reporting(0); 

include('koneksi.php');
include('css.php');


$tgl=$_GET['tanggal'];

?>
<html>
<head>
<title>Daftar Kunjungan Harian</title>
<link href="css/style_cetak.css" rel="stylesheet" type="text/css">
</head>
<body onload="window.print()">



<table style="font-family:Calibri" width="100%" border="0"  class="table-list">

<?php 
							$query=mysql_query("select * from tbl_kunjungan WHERE tanggal='$tgl' order by id DESC");
							$row=mysql_fetch_array($query);
							
							?>
							<h3 align="center" style="font-family:Calibri">DAFTAR KUNJUNGAN PASIEN<br> PUSKESMAS PUTRI AYU</h3>

</table>

<table style="font-family:Calibri" width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr align="center">
    <td width="5%" align="center" bgcolor="grey"><strong>No.</strong></td>
    <td width="10%" align="center" bgcolor="grey"><strong>Tanggal</strong></td>
    <td width="10%" align="center" bgcolor="grey"><strong>Jam </strong></td>
    <td width="10%" align="center" bgcolor="grey"><strong>Id Pasien </strong></td>
    <td width="55%%" align="center" bgcolor="grey"><strong>Nama Pasien</strong></div></td>
    <td width="10%" align="center" bgcolor="grey"><strong>Nomor Antrian</strong> </div>
  </tr>
  
 	
							
	
	
	<?php
	 
	$lihat=mysql_query("select * from tbl_kunjungan WHERE tanggal='$tgl' order by jam ASC");
	//$low=mysql_fetch_array($lihat);
	$i=0;
	while($low=mysql_fetch_array($lihat)){

	$tgl=$low[2]; 
	$i++;
	?>
  <tr>
    <td align="center"><?php echo $i; ?></td>
    <td align="center"><?=$tgl;?></td>
    <td align="center"><?=$low[3];?></td>
    <td align="center"><?=$low[1];?></td>
	<td><?php echo $row['nama']; ?></td>
	<td align="center"><?=$low[5];?><?=$low[4];?></td>
    
  </tr>
  <?php } ?>
</table>

</body>
</html>